import cli

def main2():
    cli.CLI()

if __name__ == '__main__':
    main2()
