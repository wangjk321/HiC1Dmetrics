def main():
    from .cli import CLI
    CLI()

if __name__ == '__main__':
    main()
